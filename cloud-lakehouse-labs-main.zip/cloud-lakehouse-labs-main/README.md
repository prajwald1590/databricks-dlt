# Cloud Lakehouse Labs
This repository contains the content for running the Databricks Cloud Lakehouse labs in a virtual or an in-person session.

The instructions of running the labs are documented in the notebooks.
For each lab (a subfolder under the root directory), start with the notebook **00_Introduction**.